﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Membuat objek validator untuk memeriksa dimensi vektor dan matriks
        DimensionValidator validator = new DimensionValidator();

        // Membuat objek untuk kalkulator vektor dan matriks
        VectorCalculator vectorCalculator = new VectorCalculator(validator);
        MatrixCalculator matrixCalculator = new MatrixCalculator(validator);

        // Membuat objek InputHandler untuk mengambil input dari pengguna
        InputHandler inputHandler = new InputHandler();

        // Ambil input matriks dan vektor dari user
        Matrix matrixA = inputHandler.GetMatrixInput();
        Matrix matrixB = inputHandler.GetMatrixInput();
        Vector vectorA = inputHandler.GetVectorInput();
        Vector vectorB = inputHandler.GetVectorInput();

        // Lakukan penjumlahan matriks dan vektor
        Matrix resultMatrix = matrixCalculator.Add(matrixA, matrixB);
        Vector resultVector = vectorCalculator.Add(vectorA, vectorB);

        // Tampilkan hasil penjumlahan matriks
        Console.WriteLine("Matrix Addition Result:");
        resultMatrix.Display();

        // Tampilkan hasil penjumlahan vektor
        Console.WriteLine("Vector Addition Result:");
        resultVector.Display();
    }
}

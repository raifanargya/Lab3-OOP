public class DimensionValidator
{
    // Validasi dimensi vektor
    public bool ValidateSameSize(Vector A, Vector B)
    {
        return A.Size == B.Size;
    }

    // Validasi untuk penjumlahan matriks
    public bool IsValidMatrixAddition(Matrix A, Matrix B)
    {
        return A.Rows() == B.Rows() && A.Columns() == B.Columns();
    }

    // Validasi untuk penjumlahan vektor
    public bool ValidatorVectorAddition(Vector A, Vector B)
    {
        return A.Size == B.Size;
    }
}

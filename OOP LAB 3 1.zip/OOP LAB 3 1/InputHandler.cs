using System;

public class InputHandler
{
    // Fungsi untuk input matriks dari pengguna
    public Matrix GetMatrixInput()
    {
        int rows, cols;

        // Input jumlah baris
        Console.WriteLine("Enter number of rows for the matrix: ");
        while (!int.TryParse(Console.ReadLine(), out rows) || rows <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a valid positive integer for rows.");
        }

        // Input jumlah kolom
        Console.WriteLine("Enter number of columns for the matrix: ");
        while (!int.TryParse(Console.ReadLine(), out cols) || cols <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a valid positive integer for columns.");
        }

        Matrix matrix = new Matrix(rows, cols);

        // Input nilai untuk matriks
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                double value;
                Console.Write($"Enter value for element [{i + 1},{j + 1}]: ");
                while (!double.TryParse(Console.ReadLine(), out value))
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                    Console.Write($"Enter value for element [{i + 1},{j + 1}]: ");
                }
                matrix.SetValue(i, j, value);
            }
        }

        return matrix;
    }

    // Fungsi untuk input vektor dari pengguna
    public Vector GetVectorInput()
    {
        int size;

        // Input panjang vektor
        Console.WriteLine("Enter the size of the vector: ");
        while (!int.TryParse(Console.ReadLine(), out size) || size <= 0)
        {
            Console.WriteLine("Invalid input. Please enter a valid positive integer for the vector size.");
        }

        Vector vector = new Vector(size);

        // Input nilai untuk vektor
        for (int i = 0; i < size; i++)
        {
            double value;
            Console.Write($"Enter value for element of vector [{i + 1}]: ");
            while (!double.TryParse(Console.ReadLine(), out value))
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.Write($"Enter value for element of vector [{i + 1}]: ");
            }
            vector.SetValue(i, value);
        }

        return vector;
    }
}
